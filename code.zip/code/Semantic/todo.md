
## Figures

 X - Fig 1 : sensitivity : pick year (2004 ok ?) and beautify
[Results/Semantic/Sensitivity/window5/commnum_thetaw_byyears.png,
 Results/Semantic/Sensitivity/window5/comnum_thetaw_2004.png,
 Results/Semantic/Sensitivity/window5/comnum_vcount_pareto_2004.png
 Results/Semantic/Sensitivity/window5/normalizedObjs-dispth_eth4.1e-5.png
 Results/Semantic/Sensitivity/window5/vcount_comnum_pareto.png
]
 - Fig 5 : finish layout algo and beautify
 - Fig 3 : do mean AND median for techno AND semantic
 X - Fig 4 : sizes [Results/Semantic/Analysis/window5/sizes/all_raw_counts.png]
 X - Fig 6 : patent diversities, with and without 0 diversity patents
 X - Fig 7 : intra classif overlaps : normalized and relative [Results/Semantic/Analysis/window5/overlap/{norm-patents_all_density_semcounts.png,norm-patents_all_ts_semcounts.png,relative_all_density_semcounts.png,relative_all_ts_semcounts.png}]
 X - Fig 8 : interclassif : relative [Results/Semantic/Analysis/window5/overlap/{norm-patents_interclassif_all_density_semcounts.png,norm-patents_interclassif_all_ts_semcounts.png,relative_interclassif_all_density_semcounts.png,relative_interclassif_all_ts_semcounts.png}]
 - Fig 9 : simple and overlapping modularities




